<?php
$err='{"code": 0}';
echo $err;
?>