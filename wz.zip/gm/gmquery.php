<?php
include 'telnet.class.php';
if($_POST){
	$quarr=array(
		1=>array(
			'ip'=>'127.0.0.1',
			'gm_port'=>3350,
			'gmcode'=>'abcd1234'
		)
	);
	$log='./gm.log';
	$checknum=trim($_POST['checknum']);
	if($checknum!='c3'){
		$return=array(
			'errcode'=>1,
			'info'=>'checknum error',
		);
		exit(json_encode($return));
	}
	$quid=intval($_POST['qu']);
	$qu=$quarr[$quid];
	if($qu==null){
		$return=array(
			'errcode'=>1,
			'info'=>'qu error',
		);
		exit(json_encode($return));
	}
	$uid=intval($_POST['uid']);
	if($uid<=0){
		$return=array(
			'errcode'=>1,
			'info'=>'userid error',
		);
		exit(json_encode($return));
	}
	if($_POST['type']){
		$type=trim($_POST['type']);
		switch ($type){
			case 'charge':
				$num=intval($_POST['num']);
				$orderid=time();
				if($num==0){
					$return=array(
						'errcode'=>1,
						'info'=>'num error',
					);
					exit(json_encode($return));
				}
				$telnet = new telnet($qu['ip'],$qu['gm_port']);
				$telnet->write("admin login admin {$qu['gmcode']}\r\n");
				sleep(1);
				$telnet->write("role login {$uid}\r\n");
				sleep(1);
				$telnet->write("role addcurrencyandvipexp 10200002 {$num}\r\n");
				sleep(1);
				$telnet->write("xdb set {$uid} rolepays.cangetfirstbonus true\r\n");
				sleep(1);
				$telnet->close();
					$return=array(
						'errcode'=>0,
						'info'=>'charge success'
					);
					exit(json_encode($return));
				break;
			case 'mail':
				$itemid=trim($_POST['item']);
				$num=intval($_POST['num']);
				if($num==0){
					$return=array(
						'errcode'=>1,
						'info'=>'num error',
					);
					exit(json_encode($return));
				}
				$telnet = new telnet($qu['ip'],$qu['gm_port']);
				$telnet->write("admin login admin {$qu['gmcode']}\r\n");
				sleep(1);
				$telnet->write("cs mailitemtoplayer {$uid} {$itemid} {$num} GM ItemSendOk.\r\n");
				sleep(1);
				$telnet->close();
					$return=array(
						'errcode'=>0,
						'info'=>'mail success'
					);
					exit(json_encode($return));
				break;
			default:
				$dbh = null;
				$return=array(
					'errcode'=>1,
					'info'=>'type error',
				);
				exit(json_encode($return));
				break;
		}
	}else{
		$dbh = null;
		$return=array(
			'errcode'=>1,
			'info'=>'no type',
		);
		exit(json_encode($return));
	}
}else{
	$return=array(
		'errcode'=>1,
		'info'=>'must post',
	);
	exit(json_encode($return));
}