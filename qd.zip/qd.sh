#!/bin/bash

/root/stop.sh
echo start to start all service...
cd /export/serviced
./start.sh
cd /export/auany
./start.sh
cd /export/server_1
./start.sh
cd /export/gsd
./start.sh
