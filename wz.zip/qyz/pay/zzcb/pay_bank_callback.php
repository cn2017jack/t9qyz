<?php
require_once("../config/pay_config.php");
require_once("recharge.php");
$orderid = trim($_GET['orderid']);
/*
$returncode
操作结果状态。
1 操作成功
其余皆为失败

*/
$returncode = trim($_GET['returncode']);

$userid = $eka_merchant_id;

$money	= trim($_GET['money']);

$sign	= trim($_GET['sign']);

$ext = trim($_GET['ext']);

$sign_test  = "returncode=".$returncode."&userid=".$userid."&orderid=".$orderid."&money=".$money."&keyvalue=".$eka_merchant_key;
$sign_md5 	= md5($sign_test);
$returnMsg;
if($sign_md5 == $sign)
	echo "ok";
	if($returncode == '1')
	{
		$returnMsg = "success";
		echo("<br>".$orderid);
		//////////////////////////////////////////////////////////////////////////
		// 进入到这一步，说明签名已经验证成功，
		// 你可以在这里加入自己的代码, 例如：可以将处理结果存入数据库

		doRecharge($orderid);
	}
	else
	{
		$returnMsg = "交易信息被篡改";
	}

	echo $returnMsg;
?>