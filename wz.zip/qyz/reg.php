﻿<?php
$db = null;
try {
    $host = "127.0.0.1";
    $dbname = "dqy_acc";
    $username = "root";
    $pass = "HFd66TDbP8HthSDT";
    $dsn = "mysql:host=$host;dbname=$dbname";
    $db = new PDO($dsn, $username, $pass);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //echo "mssql database connnection sucessed!";
} catch (PDOException $e) {
	$err = "0|0|DB错误";
	echo $err;
	exit;
}
$name = "";
if (isset($_GET["name"])){
	$name = $_GET['name'];
}
$pass = "";
if (isset($_GET["pass"])){
	$pass = $_GET['pass'];
}
$str_len = strlen($name);
if ($name == '' || $str_len < 4 || $str_len > 12 || !preg_match("#^[a-z0-9]+$#i", $name)) {
	$err = "0|0|用户名错误";
	echo $err;
	exit;
}
$str_len = strlen($pass);
if ($pass == '' || $str_len < 4 || $str_len > 12 || !preg_match("#^[a-z0-9]+$#i", $pass)) {
	$err = "0|0|密码错误";
	echo $err;
	exit;
}

$LoginKey = 'XZC3LnPyuV7ZWgPM3LsJ60r17kQvblBE';
$time = time();
$str = $name.$pass.$time."#".$LoginKey;
$token = md5($str);
//注册
$rs = $db->query("SELECT * FROM tb_account WHERE name='".$name."'");
$row = $rs->fetch();
if ($row["name"] == "") {
	$query = "insert tb_account"
	."(name, pass, time, token)"
	."values"
	."('".$name."','".$pass."',".$time.",'".$token."')";
	$rs = $db->query($query);

	$rs = $db->query("SELECT * FROM tb_account WHERE name='".$name."'");
	$row = $rs->fetch();
}
else {
	$err = "0|0|帐号已经被注册";
	echo $err;
	exit;
}
$userid = $row["userid"];
$err = $userid."|".$token."|注册成功";
echo $err;
?>