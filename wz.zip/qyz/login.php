﻿<?php
$db = null;
try {
    $host = "127.0.0.1";
    $dbname = "dqy_acc";
    $username = "root";
    $pass = "HFd66TDbP8HthSDT";
    $dsn = "mysql:host=$host;dbname=$dbname";
    $db = new PDO($dsn, $username, $pass);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //echo "mssql database connnection sucessed!";
} catch (PDOException $e) {
	$err = "0|0|DB错误";
	echo $err;
	exit;
}
$name = "";
if (isset($_GET["name"])){
	$name = $_GET['name'];
}
$pass = "";
if (isset($_GET["pass"])){
	$pass = $_GET['pass'];
}
$str_len = strlen($name);
if ($name == '' || $str_len < 4 || $str_len > 12 || !preg_match("#^[a-z0-9]+$#i", $name)) {
	$err = "0|0|用户名错误";
	echo $err;
	exit;
}
$str_len = strlen($pass);
if ($pass == '' || $str_len < 4 || $str_len > 12 || !preg_match("#^[a-z0-9]+$#i", $pass)) {
	$err = "0|0|密码错误";
	echo $err;
	exit;
}

$LoginKey = 'XZC3LnPyuV7ZWgPM3LsJ60r17kQvblBE';
$time = time();
$str = $name.$pass.$time."#".$LoginKey;
$token = md5($str);
//登录
$rs = $db->query("SELECT * FROM tb_account WHERE name='".$name."'");
$row = $rs->fetch();
$userid = $row["userid"];
if ($row["name"] == "") {
	$err = "0|0|帐号没注册";
	echo $err;
	exit;
}
else if ($row["pass"] != $pass) {
	$err = "0|0|密码错误";
	echo $err;
	exit;
}
else {
	$query = "UPDATE tb_account SET time=".$time.", token='".$token."' WHERE name='".$name."'";
	$rs = $db->query($query);
}
$err = $userid."|".$token."|登录成功";
echo $err;
?>