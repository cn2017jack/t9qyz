#!/bin/bash

echo start to stop all service...
cd /export/serviced
./stop.sh
cd /export/auany
./stop.sh
cd /export/server_1
./stop.sh
cd /export/gsd
./stop.sh
