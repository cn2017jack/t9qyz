<?php
require_once("zzcb/recharge.php");
//---------------------------------------

//---------------------------------------
$my_order_id = makeOrder($_POST);
//echo '创建订单: ' . $my_order_id . "\r\n";
//file_put_contents("pay_go_log1.txt","my_order_id: ".$my_order_id."\r\n");
//---------------------------------------
//doRecharge($my_order_id);
//exit();
?>


<?php

include_once("config/pay_config.php");
include_once("eka/init.php");
/*
 * 获取表单数据
 * */

$order_id = (string)$my_order_id;// date("YmdHis"); //您的订单Id号，你必须自己保证订单号的唯一性，仟易付不会限制该值的唯一性
$bankType = $_POST['paytype'];   //银行类型
$account = $_POST['name'];  //充值的账号
$amount = $_POST['cash']/100;   //充值的金额
$paytype = '';
//网银支付
//echo count($eka_card);
//exit;
/*for($i = 0; $i < count($eka_card); $i++)
{
	echo $eka_card[$i][$i];
	exit;
	if($bankType == array_values($eka_card[$i].'code'))
	{
		
		$payType = 'card';
	}
}
for($i = 0; $i < count($eka_bank); $i++)
{
	if($bankType == array_values($eka_bank[$i].'code')){	
		$payType = 'bank';
	}
}*/
if(in_array($bankType, $eka_card, true))
{
	$paytype = 'card';
}
if(in_array($bankType, $eka_bank, true))
{
	$paytype = 'bank';
}

if ('bank' == $paytype) {
    //$bankType = $_POST['bankType'];   //银行类型
	include_once("eka/class.bankpay.php");
    /*
     * 提交数据
     * */
    $bankpay = new bankpay();
    $bankpay->userid = $eka_merchant_id;  //商家Id
    $bankpay->key = $eka_merchant_key; //商家密钥
    $bankpay->bankid = $bankType;   //银行编号
    $bankpay->money = $amount;    //提交金额
    $bankpay->orderid = $order_id;   //订单Id号
    $bankpay->callbackurl = $eka_bank_callback_url; //下行异步url地址
    $bankpay->hrefbackurl = $eka_bank_hrefbackurl; //下行同步url地址

	if(($bankpay->is_mobile()))
	{
		if($bankpay->bankid == 'zhifubao' || $bankpay->bankid == 'weixin')
		{

			$bankpay->bankid = $bankpay->bankid."-wap";
		}
	}
    //发送
    $bankpay->send();
}
//卡类支付
else if ('card' == $paytype) {
    $cardType = $bankType;   //卡类型
    $card_number = $_POST['cardno'];  //卡号
    $card_password = $_POST['cardno2'];  //卡密
    /*
     * 提交数据
     * */
    include_once("eka/class.ekapay.php");
    $ekapay = new ekapay();
    $ekapay->bankid = $cardType;   //卡类型	
    $ekapay->cardNo = $card_number;   //卡号
    $ekapay->cardPwd = $card_password;  //卡密
    $ekapay->money = $amount;    //提交金额
    $ekapay->orderid = $order_id;   //订单号
    $ekapay->callbackurl = $eka_callback_url; //下行url地址
    $ekapay->userid = $eka_merchant_id;  //商家Id
    $ekapay->key = $eka_merchant_key; //商家密钥
    //发送
    $result = $ekapay->send();
}
?>