<?php
$url = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
file_put_contents('order.txt', $url.PHP_EOL, FILE_APPEND);
echo "order!!!";
?>