<?php
error_reporting(0);
header("Content-type: text/html; charset=utf-8"); 
include 'items.php';
?>
<html>
<head>
<title>青云志_GM工具</title>
<style>
  *{padding:0;margin:0}
  body{padding-left:20px;padding-top:20px}
  span{height;24px;line-height:24px;font-size:12px;min-width:100px;display:inline-block;text-align:justify;text-align-last:justify;margin-bottom:12px}
  select,input,button{height:24px;line-height:24px;font-size:12px;width:150px;display:inline-block}
</style>
</head>
<body>
<div>
  <div><span>GM校验码: </span><input type='password' value='c3' id='checknum' readonly></div>
  <div><span>选区: </span><select id='qu'><option value='1'>1区</option></select></div>
  <div><span>角色ID: </span><input type='text' value='' id='uid'></div>
  <div><span>充值: </span><input type='text' value='' id='chargenum'><input type='button' value='充值' id='chargebtn'></div>
<div><span>给后台是不够了再冲，你们可好死命的往爆号的节奏冲。</span></div>
<script src='jquery-1.7.2.min.js'></script>
<script>
  var checknum='c3';
  var uid='';
  var qu=$('#qu').val();
  $('#checknum').change(function(){
	  checknum=$(this).val();
  });
  $('#uid').change(function(){
	  uid=$.trim($(this).val());
  });
  $('#qu').change(function(){
	  qu=$.trim($(this).val());
  });
  $('#chargebtn').click(function(){
	  if(checknum==''){
		  alert('请输入GM校验码。');
		  return false;
	  }
	  if(uid==''){
		  alert('用户名不能为空。');
		  return false;
	  }
	  var chargenum=$('#chargenum').val();
	  if(chargenum=='' || isNaN(chargenum)){
		  alert('充值数量不能为空。');
		  return false;
	  }
	  if(chargenum<1 || chargenum>1000000000){
		  alert('充值数量:1-10亿。');
		  return false;
	  }
	  $.ajax({
		  url:'gmquery.php',
		  type:'post',
		  'data':{type:'charge',checknum:checknum,uid:uid,num:chargenum,qu:qu},
          'cache':false,
          'dataType':'json',
		  success:function(data){
			  console.log('data',data);
			  alert(data.info);
		  },
		  error:function(){
			  alert('充值操作失败');
		  }
	  });
  });
  $('#mailbtn').click(function(){
	  if(checknum==''){
		  alert('请输入GM校验码。');
		  return false;
	  }
	  if(uid==''){
		  alert('用户名不能为空。');
		  return false;
	  }
	  var itemid=$('#mailid').val();
	  if(itemid==''){
		  alert('请选择物品。');
		  return false;
	  }
	  var groupnum=$('#mailid').find("option:selected").data("maxnum");
	  maxnum=groupnum*5;
	  var mailnum=$('#mailnum').val();
	  if(mailnum=='' || isNaN(mailnum)){
		  alert('物品数量不能为空。');
		  return false;
	  }
	  if(mailnum<1 || mailnum>maxnum){
		  alert('物品数量:1-'+maxnum+'。');
		  return false;
	  }
	  $.ajax({
		  url:'gmquery.php',
		  type:'post',
		  'data':{type:'mail',checknum:checknum,uid:uid,item:itemid,num:mailnum,qu:qu},
          'cache':false,
          'dataType':'json',
		  success:function(data){
			  console.log('data',data);
			  alert(data.info);
		  },
		  error:function(){
			  alert('操作失败');
		  },
	  });
	  
  });
</script>
</body>
</html>