<?php

function urlsafe_b64encode($string) {
   $data = base64_encode($string);
   $data = str_replace(array('=','+','-','/'),array('_REP_','_RAP_','_RBP_','_RCP_'),$data);
   return $data;
}

function urlsafe_b64decode($string) {
   $string = str_replace(array('_REP_','_RAP_','_RBP_','_RCP_'),array('=','+','-','/'),$string);
   $data = base64_decode($string);
   return $data;
}

function makeOrder($_POST) {
	//---------------------------------------
	if(!isset($_POST["name"]) || !isset($_POST["rolename"]) || !isset($_POST["orderId"]) || !isset($_POST["cash"]) || !isset($_POST["pid"]) || !isset($_POST["desc"])) {
		exit;
	}
	$name = $_POST["name"];
	$rolename = $_POST["rolename"];
	$orderId = $_POST["orderId"];
	$cash = $_POST["cash"];
	$pid = $_POST["pid"];
	$desc = $_POST["desc"];
	$token = $_POST["token"];
	//---------------------------------------

	$mysqli = new mysqli('127.0.0.1', 'root', 'mamamiya', 'dqy_acc');
	if ($mysqli->connect_error) {
		die('Connect Error (' . $mysqli->connect_errno . ') '
				. $mysqli->connect_error);
	}
	$mysqli->set_charset("utf8");

	// 插入订单
	$sql ='insert into `tb_order`(`orderId`, `name`,`rolename`, `cash`, `payTime`, `pid`, `token`, `desc`, `payok`) values("'
		.$orderId.'", "'.$name.'", "'.$rolename.'", '.$cash.', "'.date("Y-m-d H:i:s").'", "'.$pid.'", "'.$token.'", "'.$desc.'", 0)';
	$result = $mysqli->query($sql);
	if ($result == false) {
		$error = '创建订单: ' . $sql . "\r\n";
		//echo $error;
		$arr = array('code'=>1,'errmsg'=>'数据库错误，创建订单');
		echo json_encode($arr);
		echo "<br />";
		echo $sql;
		exit();
	}
	return $orderId;
}

function doRecharge($orderid) {
	$mysqli = new mysqli('127.0.0.1', 'root', 'mamamiya', 'dqy_acc');
	if ($mysqli->connect_error) {
		die('Connect Error (' . $mysqli->connect_errno . ') '
				. $mysqli->connect_error);
	}
	$mysqli->set_charset("utf8");

	$mysqli->query('UPDATE `tb_order` SET payok=1 WHERE `orderId`="'.$orderid.'"');
	if ($result = $mysqli->query('SELECT * FROM `tb_order` WHERE `orderId`="'.$orderid.'"')) {
		if ($result->num_rows != 0) {
			$field = $result->fetch_object();
			$orderId = $field->orderId;
			$name = $field->name;
			$rolename = $field->rolename;
			$cash = $field->cash;
			$pid = $field->pid;
			$desc = $field->desc;
			//=================================================
			$agentId="1";
			$bookAmount=$cash;
			//=================================================
			$amount=$cash;
			$appId="1217";
			$appOrder=$orderId;
			$ext="";
			$generalOrder=$orderId;
			$payStatus="1";
			$serverId="1";
			$t=1;//time();
			$userIdentity=$name;
			$securityKey="1";
			$appsecret="mkssxggjy3rzmwxkvkgvhyiwofjqjj8e";
			//=================================================
			$str = $amount.$appId.$appOrder.$ext.$generalOrder
			.$payStatus.$serverId.$t.$userIdentity.$securityKey
			.$appsecret;
			$sign = md5($str);
			//=================================================
			$paycallback = "http://192.168.18.10:12000/onesdk?"
				."amount=".$amount."&appId=".$appId."&appOrder=".$appOrder."&ext=".$ext."&generalOrder=".$generalOrder
				."&payStatus=".$payStatus."&serverId=".$serverId."&t=".$t."&userIdentity=".$userIdentity."&securityKey=".$securityKey
				."&agentId=".$agentId."&bookAmount=".$bookAmount
				."&sign=".$sign;
			//echo $paycallback."<br />";
			//---------------------------------------
			$pay_result = file_get_contents($paycallback);
			//echo $pay_result."<br />";
			//file_put_contents("recharge_log2.txt","name: ".$name.", DATA: ".$pay_result."\r\n");
			if (strpos($pay_result, '{"code":0}') !== false) {
				$mysqli->query('UPDATE `tb_order` SET payok=2 WHERE `orderId`="'.$orderId.'"');
				echo '<h1><font color=red>恭喜你！购买【'.$desc.'】成功！</font></h1><br /><script>window.setTimeout("window.close();",2000);</script>';
				exit();
			}
			//---------------------------------------
		}
		/* free result set */
		$result->close();
	}
	echo "充值失败！！!<br />";
	exit();
}
?>
